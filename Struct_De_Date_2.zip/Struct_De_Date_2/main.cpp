#include <iostream>

using namespace std;

#include "subalg.h"

int main()
{
    meniu();
    return 0;
}
